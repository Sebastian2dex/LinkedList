<h3>
This module provides the singly linked list functionality in python
</h3>

# Available Methods
1) addfirst() -> appends data to the head of the linked list
2) addlast() -> appends data to the end of the linked list
3) addall() -> pass a list, and it will be converted into a linked list
4) deletefirst() -> removes the first element
5) deletelast() -> delete the last element
6) deleteall() -> wipes out the list
7) printlist() -> displays the list
